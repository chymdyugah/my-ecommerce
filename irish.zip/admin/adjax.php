<?php
	include "../conn.php";
	include "../myclasses.php";
	
	if(isset($_REQUEST['kin'])){
		$sql2 = "select prodid, name from _products";
		$result = $conn->query($sql2);
		$obj = array();
		$pad = array();
		$sing = array();
		while($row = $result->fetch_assoc()){
			$obj[] = $row['prodid'];
			$sing[] = $row['name'];
		}
		$pad[] = $sing;
		foreach($obj as $r){
			$sql = "SELECT prod_name, quant from _carts where prodid='$r'";
			$res = $conn->query($sql);
			foreach($res as $q){
				$pad[] = $q;
			}
			
		}
		
		$row = json_encode($pad);
		echo $row;
	}
	
	if(isset($_REQUEST['kit'])){
		$sql = "SELECT prod_name, SUM(quant) AS sumofsales from _carts where status='paid' GROUP BY prod_name";
		$result = $conn->query($sql);
		$obj = array();
		foreach($result as $row){
			$obj[] = $row;
		}
		$row = json_encode($obj);
		echo $row;
	}
	
	if(isset($_REQUEST['kid'])){
		$sql = "SELECT name, SUM(quantity) AS quant from _products GROUP BY name";
		$result = $conn->query($sql);
		$obj = array();
		foreach($result as $row){
			$obj[] = $row;
		}
		$row = json_encode($obj);
		echo $row;
	}
?>