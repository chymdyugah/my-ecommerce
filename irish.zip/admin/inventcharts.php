<?php
	session_start();
	if(!isset($_SESSION['email'])){
		echo "<script>location.replace('login.php')</script>";
	}
	$e = $_SESSION['email'];
	include "../conn.php";
	include "../myclasses.php";
	$user = new User($e);
	$user->getUserDetails($conn);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 2 | Blank Page</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini fixed">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>I</b>-R</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>I</b>-Rish</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">          
		<!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo($user->image) ?>" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo($user->name) ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo($user->image) ?>" class="img-circle" alt="User Image">
                <p>
                  <?php echo($user->name) ?>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo($user->image) ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo($user->name) ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="index.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
		<li>
          <a href="inventory.php">
            <i class="fa fa-table"></i> <span>Inventory Tables</span>
          </a>
        </li>
		<li>
          <a href="refill.php">
            <i class="fa fa-cart-plus"></i> <span>Make Refill</span>
          </a>
        </li>
		<li class="active">
          <a href="inventcharts.php">
            <i class="fa fa-line-chart"></i> <span>Inventory Data Analysis</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Stats and Data
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Stats</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	<div class="row">
		<div class="col-sm-7">
			<!-- Default box -->
		  <div class="box">
			<div class="box-header with-border">
			  <h3 class="box-title">Sales</h3>

			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i>
				</button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i>
				</button>
			  </div>
			</div>
				
			<div class="box-body">
              <div class="chart">
                <canvas id="lineChart" style="height:250px"></canvas>
              </div>
            </div>
            <!-- /.box-body -->
		  </div>
		  <!-- /.box -->

		</div>
	</div>
      
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
   <div class="pull-right hidden-xs">
    <strong><a href="https://adminlte.io">AdminLTE</a></strong>
    </div>
    <strong>&copy;<script>document.write(new Date().getFullYear());</script> I-rish.</strong> Developed by Chimuga Technologies. All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- ChartJS -->
<script src="bower_components/chart.js/Chart.js"></script>
<script>
  $(document).ready(function () {
    $('.sidebar-menu').tree()
  })
</script>
<script>
	function getRndInteger(min, max) {
		let x = Math.floor(Math.random() * (max - min + 1) ) + min;
		var bad = "abcdef";
		let i = Math.floor(Math.random() * (5 - 0 + 1) ) + 0;
		i = bad[i];
		let q = Math.floor(Math.random() * (max - min + 1) ) + min;
		let pre = x+i+q;
		return "#" + pre[Math.floor(Math.random() * (2 - 0 + 1) ) + 0] + pre[Math.floor(Math.random() * (2 - 0 + 1) ) + 0] + pre[Math.floor(Math.random() * (2 - 0 + 1) ) + 0];
		
	}
	$.post("adjax.php", {kin:"kin"}, function(data){
		var obj = JSON.parse(data);
		var names = [];
		var ar = [];
		var first = [];
		var prod = obj.shift(); // remove the array holding the names of all products in obj and put it in prod
		for (var a in obj){
			names.push(obj[a].prod_name);
			ar.push(obj[a].quant);
			/* var dem = {
				label:obj[a].prod_name,
				data : ar
			}
			datum.push(dem); */
		}
		for(var d in prod){
			var pat = []; 
			for(var g in obj){
				if(obj[g].prod_name == prod[d]){
					pat.push(obj[g].quant);
					
				}
				
			}
			var ruf = getRndInteger(0, 9);
			var dem = {
				data: pat,
				label: prod[d],
				fillColor: ruf,
				strokeColor         : ruf,
				pointColor          : ruf,
				pointStrokeColor    : ruf,
				pointHighlightFill  : '#fff',
				pointHighlightStroke: ruf
			}
			first.push(dem);
		}
		
		//alert(pat)
		var lineChartData = {
		  labels  : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		  datasets: first /* [
			{
			  label               : 'Electronics',
			  fillColor           : 'rgba(210, 214, 222, 1)',
			  strokeColor         : 'rgba(210, 214, 222, 1)',
			  pointColor          : 'rgba(210, 214, 222, 1)',
			  pointStrokeColor    : '#c1c7d1',
			  pointHighlightFill  : '#fff',
			  pointHighlightStroke: 'rgba(220,220,220,1)',
			  data                : [28, 48, 40, 19, 86, 27, 30]
			},
			{
			  label               : 'Digital Goods',
			  fillColor           : 'rgba(60,141,188,0.9)',
			  strokeColor         : 'rgba(60,141,188,0.8)',
			  pointColor          : '#3b8bba',
			  pointStrokeColor    : 'rgba(60,141,188,1)',
			  pointHighlightFill  : '#fff',
			  pointHighlightStroke: 'rgba(60,141,188,1)',
			  data                : [28, 48, 40, 19, 86, 27, 90]
			},
			{
			  label               : 'Cloths',
			  fillColor           : 'rgba(90,150,60,1)',
			  strokeColor         : 'rgba(90,150,60,1)',
			  pointColor          : 'rgba(90,150,60,1)',
			  pointStrokeColor    : 'rgba(90,150,60,1)',
			  pointHighlightFill  : '#fff',
			  pointHighlightStroke: 'rgba(90,150,60,1)',
			  data                : [50, 50, 10, 100, 30, 90, 48]
			}
		  ] */
		}

		var lineChartOptions = {
		  //Boolean - If we should show the scale at all
		  showScale               : true,
		  //Boolean - Whether grid lines are shown across the chart
		  scaleShowGridLines      : false,
		  //String - Colour of the grid lines
		  scaleGridLineColor      : 'rgba(0,0,0,.05)',
		  //Number - Width of the grid lines
		  scaleGridLineWidth      : 1,
		  //Boolean - Whether to show horizontal lines (except X axis)
		  scaleShowHorizontalLines: true,
		  //Boolean - Whether to show vertical lines (except Y axis)
		  scaleShowVerticalLines  : true,
		  //Boolean - Whether the line is curved between points
		  bezierCurve             : true,
		  //Number - Tension of the bezier curve between points
		  bezierCurveTension      : 1,
		  //Boolean - Whether to show a dot for each point
		  pointDot                : false,
		  //Number - Radius of each point dot in pixels
		  pointDotRadius          : 4,
		  //Number - Pixel width of point dot stroke
		  pointDotStrokeWidth     : 1,
		  //Number - amount extra to add to the radius to cater for hit detection outside the drawn point
		  pointHitDetectionRadius : 20,
		  //Boolean - Whether to show a stroke for datasets
		  datasetStroke           : true,
		  //Number - Pixel width of dataset stroke
		  datasetStrokeWidth      : 2,
		  //Boolean - Whether to fill the dataset with a color
		  datasetFill             : false,
		  //String - A legend template
		  legendTemplate          : '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
		  //Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
		  maintainAspectRatio     : true,
		  //Boolean - whether to make the chart responsive to window resizing
		  responsive              : true
		}

		var lineChartCanvas          = $('#lineChart').get(0).getContext('2d')
		var lineChart                = new Chart(lineChartCanvas)
		lineChart.Line(lineChartData, lineChartOptions)
	})
	


</script>
</body>
</html>
